TechShop - Flask skolas projekts

Apraksts:
Šī ir vienkārša Python/Flask tīmekļa lietotne datoru detaļu tiešsaistes veikalam. Projekts izmanto JSON produktu un lietotāju datiem, CSV krājuma un pieteikšanās žurnāla datiem, Jinja2 veidnes un Bootstrap 5 dizainu.

Instalēšana:
1. Atver termināli projekta mapē:
   cd computer_shop

2. Instalē nepieciešamās bibliotēkas:
   pip install flask requests

3. Ja vēlies izmantot Finnhub akciju cenu API, izveido bezmaksas API atslēgu vietnē https://finnhub.io un iestati vides mainīgo:
   PowerShell:
   $env:FINNHUB_API_KEY="TAVA_API_ATSLEGA"

4. Palaid lietotni:
   python app.py

5. Atver pārlūkā:
   http://127.0.0.1:5000

Testa lietotāji:
admin / admin123
lietotajs / parole456

Galvenie skati:
/ - visi produkti
/product/<id> - produkta detaļas
/login - pieteikšanās forma
/stocks - Nvidia un AMD akciju cenas
/category/<name> - kategorijas filtrs, piemēram /category/CPU vai /category/all
